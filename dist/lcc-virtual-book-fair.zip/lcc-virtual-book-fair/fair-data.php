<?php
/* Made by tools/build-wp-plugin.mjs from the fair's books.js. Runs on the server only. */
if (!defined('ABSPATH')) {
	exit;
}
return array(
	'build'   => '1.2.2-47af6cb1ea',
	'event'   => array('date' => '2026-11-01', 'register' => 'https://forms.gle/5ZBD2bLsYYTeYtoo9', 'registerEmbed' => 'https://docs.google.com/forms/d/e/1FAIpQLSdCwn0gwOIX2-ViHwA5tAygGIISv1m9jYFFm5BCung5iRsqGQ/viewform?embedded=true', 'zoom' => 'https://us06web.zoom.us/j/83736821137'),
	'authors' => array(
		array('id' => 'soonjin-cho', 'name' => 'Soonjin Cho', 'inbox' => 'hugloveheal@gmail.com', 'books' => array('Finding Love in the Mirror')),
		array('id' => 'edith-moricz', 'name' => 'Edith Moricz', 'inbox' => 'edith.t.moriczrfc@gmail.com', 'books' => array('Clarity Before Momentum')),
		array('id' => 'chuck-barnard', 'name' => 'Chuck Barnard', 'inbox' => 'charles.barnard@successinstitutes.co', 'books' => array('Teen Mental Health', 'More Than a Game', 'Prince and the Prodigal')),
		array('id' => 'sonia-jenkins', 'name' => 'Sonia Jenkins', 'inbox' => 'hello@soniajenkins.co.uk', 'books' => array('The Invisible Midlife Woman')),
		array('id' => 'susan-j-razavi', 'name' => 'Susan J. Razavi', 'inbox' => 'susanjrazavi@gmail.com', 'books' => array('Conscious Integrative Therapy')),
		array('id' => 'tanya-fasnacht-jolliffe', 'name' => 'Tanya Fasnacht Jolliffe', 'inbox' => 'tanya@litwellnesssolutions.com', 'books' => array('Food Isn’t the Problem')),
		array('id' => 'jessica-v-fuentes', 'name' => 'Jessica V. Fuentes', 'inbox' => 'jessica.fuentes@empowered-selflove.com', 'books' => array('The Journey to Empowerment Through Self-Love')),
		array('id' => 'jennifer-a-schmeisser', 'name' => 'Jennifer A. Schmeisser', 'inbox' => 'jensmizer@yahoo.com', 'books' => array('When the Blueprint Burned')),
		array('id' => 'monika-puiu', 'name' => 'Monika Puiu', 'inbox' => 'monika.puiu@wayra-astrae.ro', 'books' => array('Everything Happens For You')),
		array('id' => 'dolores-fazzino', 'name' => 'Dr. Dolores Fazzino', 'inbox' => 'doloresfazzino@gmail.com', 'books' => array('Healing Unraveled')),
		array('id' => 'beth-donovan', 'name' => 'Beth Donovan', 'inbox' => 'BethD101@comcast.net', 'books' => array('Life Is Happening Now')),
		array('id' => 'yevheniya-shalimova', 'name' => 'Yevheniya Shalimova', 'inbox' => 'evgenia7shalimova@gmail.com', 'books' => array('Truly Yours, Life')),
		array('id' => 'rachel-tamilio', 'name' => 'Rachel Tamilio', 'inbox' => 'rtamilio.unshackledcoach@gmail.com', 'books' => array('Curiously Certain')),
		array('id' => 'bengu-davchevski', 'name' => 'Bengü Davchevski', 'inbox' => 'bengudavchevski@gmail.com', 'books' => array('How to Build Yourself Up in Difficult Times')),
	),
);
